#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int main() {
    int x, y;
    cin >> x >> y;
    int result = 0;

    // your code

    cout << result << endl;
    return 0;
}