#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int main() {
    int r, c;
    cin >> r >> c;
    int result = 0;

    // your code

    cout << result << endl;
    return 0;
}