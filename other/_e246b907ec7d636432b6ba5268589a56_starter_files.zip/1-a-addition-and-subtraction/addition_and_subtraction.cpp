#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int main() {
    int x, y, z;
    cin >> x >> y >> z;
    int result = -1;

    // your code

    cout << result << endl;
    return 0;
}