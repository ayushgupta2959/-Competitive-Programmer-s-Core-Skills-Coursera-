import java.io.PrintWriter;
import java.util.Scanner;

public class King {
    public static void main(String[] arg) {
        Scanner in = new Scanner(System.in);
        PrintWriter out = new PrintWriter(System.out);

        int r, c;
        r = in.nextInt();
        c = in.nextInt();

        int result = 0;

        // your code

        out.println(result);

        in.close();
        out.close();
    }
}