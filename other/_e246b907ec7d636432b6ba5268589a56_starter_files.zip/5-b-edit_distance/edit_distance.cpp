#include <iostream>
#include <vector>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::vector;
using std::string;

int main() {
    int n, m;
    cin >> n >> m;
    string u, w;
    cin >> u;
    cin >> w;
    int I, D, S;
    cin >> I >> D >> S;

    int result = 0;
    // your code

    cout << result << endl;

    return 0;
}